// @ts-ignore
/* eslint-disable */
import { request } from '@/utils/request';

/** 添加班级 POST /api/class/addClass */
export async function addClass(body: API.ClassDTO, options?: { [key: string]: any }) {
  return request<number>('/api/class/addClass', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 删除班级 POST /api/class/deleteClass */
export async function deleteClass(body: number[], options?: { [key: string]: any }) {
  return request<any>('/api/class/deleteClass', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}


/** 获取单个班级信息 GET /api/class/getClass */
export async function getClass(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getClassParams,
  options?: { [key: string]: any },
) {
  return request<API.ClassDTO>('/api/class/getClass', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 获取班级列表 POST /api/class/listClass */
export async function listClass(
  body: API.ClassQueryDTO,
  options?: { [key: string]: any },
) {
  return request<API.PageClassVO>('/api/class/listClass', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}
/** 此处后端没有提供注释 POST /api/Class/updateClass */
export async function updateClass(body: API.ClassDTO, options?: { [key: string]: any }) {
  return request<number>('/api/Class/updateClass', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}