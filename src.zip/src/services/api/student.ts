// @ts-ignore
/* eslint-disable */
import { request } from '@/utils/request';

/** 此处后端没有提供注释 POST /api/student/addStudent */
export async function addStudent(body: API.StudentDTO, options?: { [key: string]: any }) {
  return request<number>('/api/student/addStudent', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/student/countStudent */
export async function countStudents(body: API.StudentQueryDTO, options?: { [key: string]: any }) {
  return request<number>('/api/student/countStudent', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/student/deleteStudent */
export async function deleteStudents(body: number[], options?: { [key: string]: any }) {
  return request<any>('/api/student/deleteStudent', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/student/exportStudent */
export async function exportStudents(body: API.StudentQueryDTO, options?: { [key: string]: any }) {
  return request<any>('/api/student/exportStudent', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 GET /api/student/getStudent */
export async function getStudent(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getStudentParams,
  options?: { [key: string]: any },
) {
  return request<API.StudentDTO>('/api/student/getStudent', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/student/getStudents */
export async function getStudents(body: API.StudentQueryDTO, options?: { [key: string]: any }) {
  return request<API.PageStudentDTO>('/api/student/getStudents', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/student/listStudent */
export async function listStudents(body: API.StudentQueryDTO, options?: { [key: string]: any }) {
  return request<API.PageStudentVO>('/api/student/listStudent', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/student/updateStudent */
export async function updateStudent(body: API.StudentDTO, options?: { [key: string]: any }) {
  return request<number>('/api/student/updateStudent', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}
