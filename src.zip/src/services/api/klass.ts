// @ts-ignore
/* eslint-disable */
import { request } from '@/utils/request';

/** 此处后端没有提供注释 POST /api/klass/addClass */
export async function addClass(body: API.ClassDTO, options?: { [key: string]: any }) {
  return request<number>('/api/klass/addClass', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/klass/deleteClass */
export async function deleteClass(body: number[], options?: { [key: string]: any }) {
  return request<any>('/api/klass/deleteClass', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 GET /api/klass/getClass */
export async function getClass(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getClassParams,
  options?: { [key: string]: any },
) {
  return request<API.ClassDTO>('/api/klass/getClass', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/klass/listClass */
export async function listClass(body: API.ClassQueryDTO, options?: { [key: string]: any }) {
  return request<API.PageClassVO>('/api/klass/listClass', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/klass/updateClass */
export async function updateClass(body: API.ClassDTO, options?: { [key: string]: any }) {
  return request<number>('/api/klass/updateClass', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}
