// @ts-ignore
/* eslint-disable */
// API 更新时间：
// API 唯一标识：
import * as admin from './admin';
import * as authentication from './authentication';
import * as department from './department';
import * as klass from './klass';
import * as loginLog from './loginLog';
import * as onlineUser from './onlineUser';
import * as score from './score';
import * as student from './student';
export default {
  student,
  score,
  loginLog,
  klass,
  department,
  authentication,
  admin,
  onlineUser,
};
