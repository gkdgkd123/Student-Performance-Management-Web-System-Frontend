// @ts-ignore
/* eslint-disable */
import { request } from '@/utils/request';

/** 此处后端没有提供注释 POST /api/score/addScore */
export async function addScore(body: API.ScoreDTO, options?: { [key: string]: any }) {
  return request<number>('/api/score/addScore', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/score/avgScores */
export async function avgScores(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAverageScoresParams,
  options?: { [key: string]: any },
) {
  return request<API.AvgDTO[]>('/api/score/avgScores', {
    method: 'POST',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/score/deleteScore */
export async function deleteScores(body: number[], options?: { [key: string]: any }) {
  return request<any>('/api/score/deleteScore', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/score/exportScore */
export async function exportScores(body: API.ScoreQueryDTO, options?: { [key: string]: any }) {
  return request<any>('/api/score/exportScore', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 GET /api/score/getScore */
export async function getScore(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getScoreParams,
  options?: { [key: string]: any },
) {
  return request<API.ScoreDTO>('/api/score/getScore', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/score/listScore */
export async function listScores(body: API.ScoreQueryDTO, options?: { [key: string]: any }) {
  return request<API.PageScoreVO>('/api/score/listScore', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/score/searchScores */
export async function getScores(body: API.ScoreQueryDTO, options?: { [key: string]: any }) {
  return request<API.PageScoreDTO>('/api/score/searchScores', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /api/score/updateScore */
export async function updateScore(body: API.ScoreDTO, options?: { [key: string]: any }) {
  return request<number>('/api/score/updateScore', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}
